xStr = input("Digite um número inteiro: ")

x = int(xStr)

d = (x // 10) % 10

print("O dígito de dezenas é: ",d)
