xStr = input("Digite o valor correspondente ao lado de um quadrado: ")

x = int(xStr)

perimetro = x*4

area = x**2

print("perímetro:", perimetro, "- área:", area)
