nota1S = input("Digite a primeira nota: ")

nota2S = input("Digite a segunda nota: ")

nota3S = input("Digite a terceira nota: ")

nota4S = input("Digite a quarta nota: ")

nota1 = float(nota1S)

nota2 = float(nota2S)

nota3 = float(nota3S)

nota4 = float(nota4S)

media = (nota1+nota2+nota3+nota4) / 4

print("A média aritmética é", media)
