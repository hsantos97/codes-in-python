numero = int(input('Digite um inteiro: '))

if (numero%3) == 0:
      print("Fizz")
else:
      print(numero)	
