numero = int(input('Digite um inteiro: '))

if ((numero%5) == 0) and ((numero%3) == 0):
      print("FizzBuzz")
else:
      print(numero)	
