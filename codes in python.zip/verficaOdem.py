a = int(input('Digite um inteiro a: '))
b = int(input('Digite um inteiro b: '))
c = int(input('Digite um inteiro c: '))

if(c > b) and (b > a):
	print("crescente")
else:
	print("não está em ordem crescente")
