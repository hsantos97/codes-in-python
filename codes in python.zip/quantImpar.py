n = int(input("Digite o valor de n: "))

i = 0
impar = 1

while i < n :
	print(impar)
	impar = impar + 2
	i = i + 1
