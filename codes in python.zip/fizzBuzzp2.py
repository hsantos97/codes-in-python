numero = int(input('Digite um inteiro: '))

if (numero%5) == 0:
      print("Buzz")
else:
      print(numero)	
