n = int(input("Digite o valor de n: "))

i = n

fatorial = 1

while i > 0 :
	fatorial = fatorial * i
	i = i - 1
print(fatorial)
