nome= input("Digite o nome do cliente: ")
dia=input("Digite o dia de vencimento: ")
mes=input("Digite o mês de vencimento: ")
valor=input("Digite o valor da fatura: ")

print("Ola", nome)
print("sua fatura com vencimento em",dia, "de", mes, "no valor de r$",valor,"esta fechada")
