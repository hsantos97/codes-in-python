def maximo (x, y):
	if x > y:
		return x
	else:
		return y
